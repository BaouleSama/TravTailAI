import React from "react";
import "./styles.css";
import { Grid } from "@material-ui/core";
import Header from "./Header";
import Content from "./Content";

const App = () => {
  return (
    <Grid container direction="column">
      <Grid item>
        <Header />
      </Grid>
      <Grid item container>
        <Grid xs={3} sm={2} />
        <Content />
      </Grid>
    </Grid>
  );
};

export default App;
