import { AppBar, Toolbar, Typography } from "@material-ui/core";
import React from "react";
import AddShoppingCartIcon from "@material-ui/icons/AddShoppingCart";
const Header = () => {
  return (
    <AppBar position="static">
      <Toolbar>
        <Typography>TravTail.AI</Typography>
        <AddShoppingCartIcon />
      </Toolbar>
    </AppBar>
  );
};

export default Header;
