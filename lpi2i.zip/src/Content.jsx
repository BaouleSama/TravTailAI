import React from "react";
import CoffeCard from "./Content";
import { Grid } from "@material-ui/core";

const Content = () => {
  return (
    <Grid container>
      <Grid item xs={4}>
        <CoffeCard />
      </Grid>
      <Grid item xs={4}>
        <CoffeCard />
      </Grid>
      <Grid item xs={4}>
        <CoffeCard />
      </Grid>
    </Grid>
  );
};

export default Content;
